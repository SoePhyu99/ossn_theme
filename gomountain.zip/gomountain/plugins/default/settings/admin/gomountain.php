<?php
echo ossn_view_form('gomountain/settings', array(
    'action' => ossn_site_url() . 'action/gomountain/settings',
	'class' => 'gomountain-form-admin',	
));

