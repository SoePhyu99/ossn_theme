<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('es', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'Logotipo del sitio',
	'theme:gomountain:logo:admin' => 'Logotipo de la administraci�n',
	'theme:gomountain:logo:large' => '�El archivo del logo es demasiado grande!',
	'theme:gomountain:logo:failed' => 'La subida del logo fall�',
	'theme:gomountain:logo:changed' => 'El logo ha sido cambiado.',
	'theme:gomountain:browercache' => 'En caso de que las im�genes no aparezcan. Por favor, borre la memoria cach� de su navegador para que aparezcan las im�genes.'
));