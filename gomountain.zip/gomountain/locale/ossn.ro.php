<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('ro', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'Logo-ul site-ului',
	'theme:gomountain:logo:admin' => 'Logo-ul Admin',
	'theme:gomountain:logo:large' => 'Fișierul logo este prea mare!',
	'theme:gomountain:logo:failed' => 'Încărcarea logo-ului a eșuat',
	'theme:gomountain:logo:changed' => 'Logo-ul a fost schimbat.',
	'theme:gomountain:browercache' => 'În cazul în care imaginile nu apar. Vă rugăm să ștergeți memoria cache a browserului web pentru ca imaginile să apară.'
));
