<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$en = array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'Site Logo',
	'theme:gomountain:logo:admin' => 'Admin Logo',
	'theme:gomountain:logo:large' => 'Logo file is too large!',
	'theme:gomountain:logo:failed' => 'Logo upload failed',
	'theme:gomountain:logo:changed' => 'Logo has been changed.',
	'theme:gomountain:browercache' => 'In case images does not appear. Please clear your web browser cache to make the images appear'
);
ossn_register_languages('en', $en);