<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('tr', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'Site Logosu',
	'theme:gomountain:logo:admin' => 'Yönetici Logosu',
	'theme:gomountain:logo:large' => 'Logo dosyası çok büyük!',
	'theme:gomountain:logo:failed' => 'Logo yüklenemedi',
	'theme:gomountain:logo:changed' => 'Logo değiştirildi.',
	'theme:gomountain:browercache' => 'Görüntülerin görünmemesi durumunda. Görüntülerin görünmesi için lütfen web tarayıcı önbelleğinizi temizleyin.'
));
