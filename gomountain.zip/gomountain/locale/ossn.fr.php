<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('fr', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'Logo du site',
	'theme:gomountain:logo:admin' => "Logo de l'administration",
	'theme:gomountain:logo:large' => 'Le fichier du logo est trop volumineux !',
	'theme:gomountain:logo:failed' => 'Le t�l�chargement du logo a �chou�',
	'theme:gomountain:logo:changed' => 'Le logo a �t� modifi�.',
	'theme:gomountain:browercache' => "Au cas o� les images n'apparaissent pas. Veuillez vider le cache de votre navigateur web pour faire appara�tre les images"
));