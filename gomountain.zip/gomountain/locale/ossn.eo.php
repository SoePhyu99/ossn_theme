<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('eo', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'Loko Logo',
	'theme:gomountain:logo:admin' => 'Logoo de Admin',
	'theme:gomountain:logo:large' => 'Logo-dosiero estas tro granda!',
	'theme:gomountain:logo:failed' => 'Logo-sargo malsukcesis',
	'theme:gomountain:logo:changed' => 'Logo estis sangita.',
	'theme:gomountain:browercache' => 'Kaze ne bildoj aperas. Bonvolu forigi la kasmemoron de via retumilo por aperigi la bildojn'
));