<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('ru', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'Логотип сайта',
	'theme:gomountain:logo:admin' => 'Логотип администратора',
	'theme:gomountain:logo:large' => 'Файл с логотипом слишком большой!',
	'theme:gomountain:logo:failed' => 'Загрузка логотипа не удалась',
	'theme:gomountain:logo:changed' => 'Логотип изменен.',
	'theme:gomountain:browercache' => 'В случае, если изображения не появляются. Пожалуйста, очистите кэш веб-браузера, чтобы изображения появились.'
));
