<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('nl', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'Logo van de site',
	'theme:gomountain:logo:admin' => 'Admin Logo',
	'theme:gomountain:logo:large' => 'Logobestand is te groot!',
	'theme:gomountain:logo:failed' => 'Logo upload mislukt',
	'theme:gomountain:logo:changed' => 'Het logo is veranderd.',
	'theme:gomountain:browercache' => 'Voor het geval dat er geen beelden verschijnen. Verwijder de cache van uw webbrowser om de afbeeldingen te laten verschijnen.'
));
