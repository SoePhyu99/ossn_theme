<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('ja', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'サイトロゴ',
	'theme:gomountain:logo:admin' => '管理者のロゴ',
	'theme:gomountain:logo:large' => 'ロゴファイルが大きすぎる',
	'theme:gomountain:logo:failed' => 'ロゴのアップロードに失敗しました',
	'theme:gomountain:logo:changed' => 'ロゴを変更しました。',
	'theme:gomountain:browercache' => '画像が表示されない場合 画像が表示されるように、ブラウザのキャッシュをクリアしてください。'
));
