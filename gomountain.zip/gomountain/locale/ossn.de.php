<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('de', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'Logo der Website',
	'theme:gomountain:logo:admin' => 'Admin Logo',
	'theme:gomountain:logo:large' => 'Logo-Datei ist zu gro�!',
	'theme:gomountain:logo:failed' => 'Logo-Upload fehlgeschlagen',
	'theme:gomountain:logo:changed' => 'Logo wurde ge�ndert.',
	'theme:gomountain:browercache' => 'Falls Bilder nicht erscheinen. Bitte l�schen Sie den Cache Ihres Webbrowsers, damit die Bilder angezeigt werden k�nnen.'
));