<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('he', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'לוגו האתר',
	'theme:gomountain:logo:admin' => 'לוגו המינהלo',
	'theme:gomountain:logo:large' => 'קובץ הלוגו גדול מדי!',
	'theme:gomountain:logo:failed' => 'העלאת הלוגו נכשלה',
	'theme:gomountain:logo:changed' => 'הלוגו שונה.',
	'theme:gomountain:browercache' => 'במקרה שהתמונות לא מופיעות. אנא נקה את זיכרון המטמון של דפדפן האינטרנט שלך בכדי לגרום לתמונות להופיע'
));