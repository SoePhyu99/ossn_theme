<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network (OSSN)
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('it', array(
	'gomountain:settings' => 'GoMountain',
	'admin:theme:gomountain' => 'GoMountain',
	'theme:gomountain:logo:site' => 'Logo del sito',
	'theme:gomountain:logo:admin' => 'Logo amministratore',
	'theme:gomountain:logo:large' => 'Il file del logo è troppo grande!',
	'theme:gomountain:logo:failed' => 'Caricamento del logo non riuscito',
	'theme:gomountain:logo:changed' => 'Il logo è stato cambiato.',
	'theme:gomountain:browercache' => 'Nel caso in cui le immagini non vengano visualizzate. Svuota la cache del browser Web per visualizzare le immagini.'
));